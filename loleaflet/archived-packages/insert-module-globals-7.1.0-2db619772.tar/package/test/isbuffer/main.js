module.exports = function (buf) {
    return Buffer.isBuffer(buf);
};
