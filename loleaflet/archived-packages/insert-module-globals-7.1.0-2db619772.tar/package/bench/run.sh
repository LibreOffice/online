#!/bin/bash
time module-deps bench/jquery.js | bin/cmd.js >/dev/null
