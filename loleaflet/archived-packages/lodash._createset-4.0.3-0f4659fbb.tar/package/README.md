# lodash._createset v4.0.3

The internal [lodash](https://lodash.com/) function `createSet` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash._createset
```

In Node.js:
```js
var createSet = require('lodash._createset');
```

See the [package source](https://github.com/lodash/lodash/blob/4.0.3-npm-packages/lodash._createset) for more details.
