# lodash._baseuniq v4.6.0

The internal [lodash](https://lodash.com/) function `baseUniq` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash._baseuniq
```

In Node.js:
```js
var baseUniq = require('lodash._baseuniq');
```

See the [package source](https://github.com/lodash/lodash/blob/4.6.0-npm-packages/lodash._baseuniq) for more details.
